// routes
const accountsRouter = require('./accounts');
const productsRouter = require('./products');
const cartsRouter = require('./carts');
const categoriesRouter = require('./categories');
const propertiesRouter = require('./properties');
const locationsRouter = require('./locations');
const ordersRouter = require('./orders');
const paymentRouter = require('./payment');
const operationsRouter = require('./operations');
const resourcesRouter = require('./resources');
const rolesRouter = require('./roles');
const attributevaluesRouter = require('./attributevalues');
const warrantiesRouter = require('./warranties');
const specificationsRouter = require('./specifications');
const dashboardRouter = require('./dashboard');

const initialRoutes = (app) => {
	app.use('/api/accounts', accountsRouter);
	app.use('/api/products', productsRouter);
	app.use('/api/carts', cartsRouter);
	app.use('/api/categories', categoriesRouter);
	app.use('/api/properties', propertiesRouter);
	app.use('/api/locations', locationsRouter);
	app.use('/api/orders', ordersRouter);
	app.use('/api/payment', paymentRouter);
	app.use('/api/operations', operationsRouter);
	app.use('/api/resources', resourcesRouter);
	app.use('/api/roles', rolesRouter);
	app.use('/api/attributevalues', attributevaluesRouter);
	app.use('/api/warranties', warrantiesRouter);
	app.use('/api/specifications', specificationsRouter);
	app.use('/api/dashboard', dashboardRouter);
};

module.exports = initialRoutes;
